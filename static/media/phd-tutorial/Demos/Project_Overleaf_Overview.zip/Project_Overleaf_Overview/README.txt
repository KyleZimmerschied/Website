PhD Tutorial Project
====================

Contents
--------
- Finalized Data/StataIssuancePanel.dta
- Code/Stata/00_master.do
- Code/Stata/01_make_summary_table.do
- Code/Stata/02_make_regression_table.do
- Code/Stata/03_make_figure.do
- Code/Stata/export_figure_from_r.R
- Overleaf/main.tex
- Overleaf/advanced_main.tex

Suggested workflow
------------------
1. Open the project root in Stata.
2. Run Code/Stata/00_master.do.
3. This creates:
   - Output/Tables/TAB_SUMMARY_BOND.tex
   - Output/Tables/OLS_YIELD.tex
   - Output/Figures/FIG_YIELD_SCATTER.png
4. Upload these generated files plus Overleaf/main.tex to Overleaf.
5. In Overleaf, either:
   - place the .tex fragments and figure in the same folder as main.tex, or
   - adjust the file paths in main.tex.

Notes
-----
- The dataset is synthetic, so students can share it freely.
- The code is deliberately simple and tutorial-friendly.
- I also included an R script if you want to demonstrate figure export from R.
- I also created Overleaf/advanced_main.tex which files similar Latex formatting to my workflow (have to set Latex Version to 2020)