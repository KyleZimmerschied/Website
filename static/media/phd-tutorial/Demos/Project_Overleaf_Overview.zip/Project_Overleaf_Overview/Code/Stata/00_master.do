*===============================================================================
* Date: March 2026
* Author: Kyle Zimmerschied
*
* Master file for PhD tutorial:
*   1. Summary statistics table
*   2. Regression table
*   3. Figure export
*
* Before running:
*   - Open this project folder in Stata
*   - Make sure the working directory is the project root
*===============================================================================
clear all /* Clear existing output */
*-----------------------------*
* 0. Project paths
*-----------------------------*
cd /*Check your current working directory */

global project_root "C:\Users/kylez/Dropbox/Teaching/Finance PhD Tutorial/Project_Overleaf_Overview"  /*This will set your working directory to the main Project_Overleaf_Overview folder*/
di "$project_root" /*Check to make sure this is something like C:\Users/kylez/Dropbox/Teaching/Finance PhD Tutorial/Project_Overleaf_Overview */

global data_path      "$project_root/Finalized Data" /*This is path to access finalized data*/
global do_path        "$project_root/Code/Stata" /*This is path to run Stata code files*/
global main_output_path "$project_root/Output/Tables" /*This is the path to produce Tables*/
global fig_path       "$project_root/Output/Figures" /*This is the path to produce Figures*/
*-----------------------------*
* 1. Make sure packages exist
*-----------------------------*
cap which esttab /*Check if package exists*/
if _rc ssc install estout, replace /*Install package if it doesn't exist*/

cap which reghdfe /*Check if package exists*/
if _rc ssc install reghdfe, replace /*Install package if it doesn't exist*/

cap which ftools /*Check if package exists*/
if _rc ssc install ftools, replace /*Install package if it doesn't exist*/
*-----------------------------*
* 2. Run each tutorial step
*-----------------------------*
do "$do_path/01_make_summary_table.do"
do "$do_path/02_make_regression_table.do"
do "$do_path/03_make_figure.do"

display as text "Tutorial outputs created in:"
display as result "$main_output_path"
display as result "$fig_path"
