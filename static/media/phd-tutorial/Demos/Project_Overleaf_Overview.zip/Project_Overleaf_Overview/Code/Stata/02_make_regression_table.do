*===============================================================================
* TABLE YIELDS: CENSUS
*===============================================================================
*LOAD IN DATA
*===============================================================================
clear /* Clear working directory */
use "$data_path/StataIssuancePanel.dta", clear /* Load in Data */
*===============================================================================
*MAKE SURE FIXED EFFECTS GROUPS ARE DEFINED PROPERLY
*===============================================================================
* Encode ratings because absorb() needs numeric variables
capture confirm numeric variable ratings_comb
if _rc {
    encode ratings_comb, gen(ratings_comb_fe)
}
else {
    gen ratings_comb_fe = ratings_comb
}

* Fixed effects identifiers
egen state_year = group(state_fips year)
egen state_county_year = group(state_fips county_fips year)
*===============================================================================
*CREATE SOME DYNAMIC CONTROLS WE CAN AUTOMATICALLY CHANGE
*===============================================================================
* Main regressor and controls
global endog_x new_prop_immigration

*List of bond controls
global bond_controls years_to_maturity amount_final_mat_mil callable_issue ///
    insured_flag negotiated_bid_flag revenue_type_flag tax_exempt_flag ///
    sinking_fund_flag refinancing_refunding_flag

*List of county controls
global county_controls total_population full_unemployment_rate ///
    f_average_income f_prop_below_poverty

eststo clear 
*===============================================================================
*LABEL A VARIABLE FOR THE TABLE
*===============================================================================
la var new_prop_immigration "\% Immigration" /* Stata also has shortcuts like this we can use */
*===============================================================================
*STORE TABLE OBJECTS
*===============================================================================
reghdfe final_mat_yield_ta_rf_w $endog_x if in_sample == 1, /// This runs your regression in subsample
    absorb(state_year) cluster(state_fips) /*This sets the fixed effects and level of clustering*/
eststo A /*Store output*/
estadd local state_fe "Yes"
estadd local year "Yes"
estadd local county_fe "No"
estadd local bond_controls "No"
estadd local county_controls "No"
quietly summarize final_mat_yield_ta_rf_w if e(sample) /*Summarize your y-variable if in-sample */
estadd scalar ymean = r(mean) /*Store this as output from the regression */

reghdfe final_mat_yield_ta_rf_w $endog_x $bond_controls if in_sample == 1, ///
    absorb(state_year ratings_comb_fe) cluster(state_fips)
eststo B
estadd local state_fe "Yes"
estadd local year "Yes"
estadd local county_fe "No"
estadd local bond_controls "Yes"
estadd local county_controls "No"
quietly summarize final_mat_yield_ta_rf_w if e(sample)
estadd scalar ymean = r(mean)

reghdfe final_mat_yield_ta_rf_w $endog_x $county_controls if in_sample == 1, ///
    absorb(state_year) cluster(state_fips)
eststo C
estadd local state_fe "Yes"
estadd local year "Yes"
estadd local county_fe "No"
estadd local bond_controls "No"
estadd local county_controls "Yes"
quietly summarize final_mat_yield_ta_rf_w if e(sample)
estadd scalar ymean = r(mean)

reghdfe final_mat_yield_ta_rf_w $endog_x $bond_controls $county_controls ///
    if in_sample == 1, absorb(state_year ratings_comb_fe) cluster(state_fips)
eststo D
estadd local state_fe "Yes"
estadd local year "Yes"
estadd local county_fe "No"
estadd local bond_controls "Yes"
estadd local county_controls "Yes"
quietly summarize final_mat_yield_ta_rf_w if e(sample)
estadd scalar ymean = r(mean)

reghdfe final_mat_yield_ta_rf_w $endog_x if in_sample == 1, ///
    absorb(state_county_year) cluster(state_fips)
eststo E
estadd local state_fe "No"
estadd local year "Yes"
estadd local county_fe "Yes"
estadd local bond_controls "No"
estadd local county_controls "No"
quietly summarize final_mat_yield_ta_rf_w if e(sample)
estadd scalar ymean = r(mean)

reghdfe final_mat_yield_ta_rf_w $endog_x $bond_controls if in_sample == 1, ///
    absorb(state_county_year ratings_comb_fe) cluster(state_fips)
eststo F
estadd local state_fe "No"
estadd local year "Yes"
estadd local county_fe "Yes"
estadd local bond_controls "Yes"
estadd local county_controls "No"
quietly summarize final_mat_yield_ta_rf_w if e(sample)
estadd scalar ymean = r(mean)

reghdfe final_mat_yield_ta_rf_w $endog_x $county_controls if in_sample == 1, ///
    absorb(state_county_year) cluster(state_fips)
eststo G
estadd local state_fe "No"
estadd local year "Yes"
estadd local county_fe "Yes"
estadd local bond_controls "No"
estadd local county_controls "Yes"
quietly summarize final_mat_yield_ta_rf_w if e(sample)
estadd scalar ymean = r(mean)

reghdfe final_mat_yield_ta_rf_w $endog_x $bond_controls $county_controls ///
    if in_sample == 1, absorb(state_county_year ratings_comb_fe) cluster(state_fips)
eststo H
estadd local state_fe "No"
estadd local year "Yes"
estadd local county_fe "Yes"
estadd local bond_controls "Yes"
estadd local county_controls "Yes"
quietly summarize final_mat_yield_ta_rf_w if e(sample)
estadd scalar ymean = r(mean)
*===============================================================================
*BUILD TABLE
*===============================================================================
* Now send this table to LaTeX
esttab A B C D E F G H using "$main_output_path/OLS_YIELD.tex", /// Send Objects to designated file path
    booktabs fragment brackets replace se(3) b(3) label nobaselevels /// Latex formatting and decimal places
    keep($endog_x) /// Which regression variables do you want to show--here we only show the endogenous x variable
    star(* 0.1 ** 0.05 *** 0.01) nonotes nomtitles nolines /// Latex formatting with stars
    posthead(\midrule) obslast /// Latex formatting
    stats(N r2_a state_fe year county_fe bond_controls county_controls ymean, /// Which locals from regression do you want to show
    fmt(0 2 0 0 0 0 0 2) /// How many decimal places to show for each local print-out (fixed effects are 0 while numeric is 2)
    labels(`"Observations"' "Adjusted \( R^2 \)" "State F.E." "Year F.E." /// What are the names of these local print outs for the bottom of the table
    "County F.E." "Bond Controls" "County Controls" "Y-mean")) ///
    mgroups("Yield Spread", pattern(1 0 0 0 0 0 0 0) /// What is the name of your dependent variable(s) we should have a number for every column we have--if multiple different column names you should have a 1 instead of zero where you want the new name to appear
    prefix(\multicolumn{@span}{c}{) suffix(}) /// Latex Formatting
    span erepeat(\cmidrule(lr){@span})) /*Latex Formatting */
