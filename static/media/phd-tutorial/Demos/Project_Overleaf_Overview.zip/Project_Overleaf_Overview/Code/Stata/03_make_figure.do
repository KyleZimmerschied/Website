*===============================================================================
* SIMPLE FIGURE EXPORT FOR OVERLEAF
*Sample Plot
*===============================================================================
*LOAD IN DATA
*===============================================================================
clear /* Clear working directory */
use "$data_path/StataIssuancePanel.dta", clear /* Load in Data */
*===============================================================================
*MAKE PLOT
*===============================================================================
twoway ///
    (scatter final_mat_yield_ta_rf_w new_prop_immigration if in_sample == 1, ///
        mcolor(navy%35) msymbol(oh) msize(vsmall)) ///
    (lfit final_mat_yield_ta_rf_w new_prop_immigration if in_sample == 1, ///
        lcolor(maroon) lwidth(medthick)), ///
    graphregion(color(white)) ///
    xtitle("New immigrant share") ///
    ytitle("Yield spread") ///
    title("Yield spreads and immigration exposure") ///
    legend(off)
*===============================================================================
*EXPORT PLOT
*===============================================================================
graph export "$fig_path/FIG_YIELD_SCATTER.png", replace width(1800)
