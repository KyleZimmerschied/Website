*===============================================================================
* Date: March 2026
* Author: Kyle Zimmerschied
*
* This program examines the data at the issuance level and creates
* summary statistics tables.
*
* Database used: "Finalized Data/StataIssuancePanel.dta"
* Output: Summary Statistics
*===============================================================================
*LOAD IN DATA
*===============================================================================
clear /* Clear working directory */
use "$data_path/StataIssuancePanel.dta", clear /* Load in Data */
*===============================================================================
*CREATE VARIABLE LIST FOR TABLE YOU'LL CALL BELOW
*===============================================================================
** This is at the bond level
*This makes a nice list of variables we can call below in our table
global xlist1 final_mat_yield_ta_rf_w years_to_maturity amount_final_mat_mil ///
    composite_amount_usd_millions callable_issue insured_flag negotiated_bid_flag ///
    revenue_type_flag tax_exempt_flag sinking_fund_flag refinancing_refunding_flag

*These are some other example lists you could create for separate panels
** This is at the county characteristics level
*global xlist2 total_population immigration l_nta_immigration new_prop_immigration ///
*    new_prop_population_change mean_full_prop_undocumented net_flow ///
*    full_unemployment_rate full_labor_force_part distance_us_border ///
*    f_prop_working_pop f_prop_below_poverty f_average_income f_median_age_pop ///
*    total_emp prop_li_emp
*
** Look at Census Wages
*global xlist3 estab_count employee_lev total_annual_wages_c avg_annual_pay_c
*
*** County income and expenses
*global xlist4 a_total_revenue a_total_taxes a_property_tax a_tot_sales_gr_rec_tax ///
*    a_total_ig_revenue a_total_fed_ig_revenue a_total_state_ig_revenue ///
*    a_tot_local_ig_rev a_total_expenditure a_total_capital_outlays ///
*    a_total_highways_tot_exp a_parks_rec_total_exp a_judicial_total_expend ///
*    a_health_total_expend a_police_prot_total_exp a_public_welf_total_exp ///
*    a_net_income_margin a_total_debt_outstanding a_total_long_term_debt_out ///
*    a_total_cash_securities a_nonin_trust_cash_sec a_oth_nonin_fd_cash_sec ///
*    a_leverage_total_assets

*===============================================================================
* Optional labels so the table looks cleaner: SET LABELS
*===============================================================================
label variable final_mat_yield_ta_rf_w        "Final maturity yield spread"
label variable years_to_maturity              "Years to maturity"
label variable amount_final_mat_mil           "Amount at final maturity (USD mil.)"
label variable composite_amount_usd_millions  "Composite amount (USD mil.)"
label variable callable_issue                 "Callable issue"
label variable insured_flag                   "Insured"
label variable negotiated_bid_flag            "Negotiated bid"
label variable revenue_type_flag              "Revenue bond"
label variable tax_exempt_flag                "Tax exempt"
label variable sinking_fund_flag              "Sinking fund"
label variable refinancing_refunding_flag     "Refunding / refinancing"
la var new_prop_immigration "\% Immigration" /* Stata also has shortcuts like this we can use */
*===============================================================================
* TABLE 1a: Summary Table Bond
*===============================================================================
{
    qui estpost su $xlist1 if in_sample == 1, detail /*This will quietly create a table which stores the outputs we'll call below*/
    est store A /* This will store the output in an object we'll call below */

    esttab A using "$main_output_path/TAB_SUMMARY_BOND.tex", replace /// /*This will export the object A to the tex file in the file path we've specified
        b(a2) /// /*This has to do with decimal formatting */
        collabels(\multicolumn{1}{c}{{N}} \multicolumn{1}{c}{{Mean}} /// */These are objects from A that we will produce in our Table */
        \multicolumn{1}{c}{{SD}} \multicolumn{1}{c}{{p1}} /// */These are objects from A that we will produce in our Table */
        \multicolumn{1}{c}{{p25}} \multicolumn{1}{c}{{Median}} /// */These are objects from A that we will produce in our Table */
        \multicolumn{1}{c}{{p75}} \multicolumn{1}{c}{{p99}}) /// */These are objects from A that we will produce in our Table */
        cells("count mean(fmt(%10.2fc)) sd(fmt(%10.2fc)) p1(fmt(%10.2fc)) p25(fmt(%10.2fc)) p50(fmt(%10.2fc)) p75(fmt(%10.2fc)) p99(fmt(%10.2fc))") /// */Additional formatting/*
        label booktabs nonumber noobs fragment nonotes nomtitles nolines /// /*Latex formatting */
        posthead(\midrule) /*Latex formatting */
}
