#LOAD IN Packages
#If these aren't installed, you can do so like install.packages("arrow") and then library them
library(arrow)
library(dplyr)
library(ggplot2)
library(haven)
#===============================================================================
                        #SET DIRECTORIES
#===============================================================================
getwd() #Check your working directory
#You'll need to change this to your path
setwd("C:/Users/kylez/Dropbox/Teaching/Finance PhD Tutorial/Project_Overleaf_Overview/") #Set this to the same as Stata to the Project_Overleaf_Overview Main Folder
getwd() #Check this worked properly

#Set paths for data and figures
data_path <- "Finalized Data/StataIssuancePanel.dta"
fig_path  <- "Output/Figures/FIG_YIELD_SCATTER_R.png"
#===============================================================================
                      #READ IN DATA
#===============================================================================
df <- read_dta(data_path)
#===============================================================================
                      #MAKE YOUR PLOT
#===============================================================================
p <- df %>%
  filter(in_sample == 1) %>%
  ggplot(aes(x = new_prop_immigration, y = final_mat_yield_ta_rf_w)) +
  geom_point(alpha = 0.35) +
  geom_smooth(method = "lm", se = FALSE) +
  labs(
    title = "Yield spreads and immigration exposure",
    x = "% Immigration",
    y = "Yield spread"
  ) +
  # Now change the theme
  theme_bw() +
  
  # Now label this better
  theme(
    plot.title = element_text(size = 12, hjust = 0.5, color = "black"),
    axis.text.x = element_text(size = 12, color = "black"), 
    axis.title.x = element_text(size = 12, color = "black"),
    axis.text.y = element_text(size = 12, color = "black"), 
    axis.title.y = element_text(size = 12, color = "black"),
    legend.text = element_text(size = 12, color = "black"),
    legend.title = element_text(size = 12, color = "black"),
    legend.position = "bottom")
#===============================================================================
                      #SAVE YOUR PLOT
#===============================================================================
ggsave(
  filename = fig_path,
  plot = p,
  width = 7,
  height = 4.5,
  dpi = 300
)
